-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2023 at 04:44 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myat1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `AdminName` varchar(100) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Role` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `AdminName`, `Email`, `Password`, `Role`) VALUES
(1, 'Myint', '0', '123', 'admin'),
(2, 'Myint', '0', '123', 'admin'),
(3, 'Chaw', '0', '123', 'admin'),
(4, 'Thae', 'thae1@gmail.com', '123', 'admin'),
(5, 'Myat Maungs', 'm@gmail.com', 'mm', 'admin'),
(6, 'Thae', 'thae1@gmail.com', '123', 'admin'),
(7, 'Myat Maung Admin', 'Admin@gmail.com', 'admin', 'admin'),
(8, 'admin', 'myatmaung3350@gmail.com', '123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `catagories`
--

CREATE TABLE `catagories` (
  `catID` int(11) NOT NULL,
  `catName` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `catagories`
--

INSERT INTO `catagories` (`catID`, `catName`) VALUES
(5, 'Camera'),
(6, 'Laptops'),
(7, 'Phone'),
(8, 'accessories');

-- --------------------------------------------------------

--
-- Table structure for table `orderitem`
--

CREATE TABLE `orderitem` (
  `id` int(11) NOT NULL,
  `productID` int(20) NOT NULL,
  `order_id` int(20) NOT NULL,
  `qty` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productID` int(11) NOT NULL,
  `productName` varchar(50) NOT NULL,
  `catID` int(11) NOT NULL,
  `price` varchar(90) NOT NULL,
  `productPhoto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productID`, `productName`, `catID`, `price`, `productPhoto`) VALUES
(28, 'Sony Alpha 7C', 5, '1500', 'sony_dslr.jpeg'),
(29, 'Cannon EOS', 5, '2000', 'cannon_eos.jpg'),
(30, 'Olympus ', 5, '2500', 'olympus.jpg'),
(32, 'MacBook pro M2', 6, '3000', '2023-MacBook-Pro-models-13.webp'),
(33, 'MacBook Pro 13 M1', 6, '1500', 'apple-macbook-pro-13-inch-macbook-pro-13-inch-m1-space-grey-2020-excellent-29264841179238.webp'),
(34, 'MacBook Pro 16 M3', 6, '3500', 'space-black-macbook-pro-back-angle-14.webp'),
(35, 'I Phone 15 Pro', 7, '1500', 'iphone-15-pro-finish-select-202309-6-1inch-bluetitanium.jpg'),
(36, 'I Phone 15 Pro', 7, '1500', 'iphone-15-pro-finish-select-202309-6-1inch-whitetitanium_AV1.jpg'),
(37, 'I Phone 15 Pro Max', 7, '1999', 'iphone-15-pro-finish-select-202309-6-1inch-bluetitanium.jpg'),
(38, 'Favreleuba', 8, '300', 'favreleuba.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

CREATE TABLE `tblorder` (
  `order_id` int(11) NOT NULL,
  `uid` int(20) NOT NULL,
  `order_date` varchar(50) NOT NULL,
  `phone` int(60) NOT NULL,
  `address` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `email`) VALUES
(1, 'Myat', 'pw', 'user', 'myat@gmail.com'),
(2, 'Myat', 'my', 'user', 'Myat@gmail.com'),
(3, 'Myat', 'Myint', 'user', 'myatmaung1212@gmail.com'),
(4, 'min', 'min', 'user', 'min@gmail.com'),
(5, '', '', 'user', 'o@gmail.com'),
(6, 'o', '', 'user', 'o@gmail.com'),
(7, 'o', 'o', 'user', 'o@gmail.com'),
(8, 'ma', 'mama', 'user', 'ma@gmail.com'),
(9, 'Myat Maung', '1212', 'user', 'myat1@gmail.com'),
(10, 'Myint', '123', 'user', 'myint2@gmail.com'),
(11, 'Myat Maung', '121202', 'user', 'myatmaung3350@gmail.com'),
(12, 'Kmklmmm', 'lelelrlr', 'user', 'lee@gmail.com'),
(13, 'lee', '123456', 'user', 'lee@gmail.com'),
(14, 'marc', '12345', 'user', 'myatmaung3350@gmail.com'),
(15, 'Marc', '123', 'user', 'marc@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catagories`
--
ALTER TABLE `catagories`
  ADD PRIMARY KEY (`catID`);

--
-- Indexes for table `orderitem`
--
ALTER TABLE `orderitem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productID`);

--
-- Indexes for table `tblorder`
--
ALTER TABLE `tblorder`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `catagories`
--
ALTER TABLE `catagories`
  MODIFY `catID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orderitem`
--
ALTER TABLE `orderitem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tblorder`
--
ALTER TABLE `tblorder`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
