<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>Edit Category</title>
</head>
<body>
<h1>Edit Category</h1>
<?php 
    include("dbconnection.php");
    $id=$_GET['id'];
    $result=$db1->query("SELECT * FROM catagories WHERE catID=$id");
    if($result->rowCount() >0){
        foreach($result  as $row){
            $catID=$row['catID'];
            $catName=$row['catName'];
        }
    }
?>
<form method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $catID ?>">

<label for="name">Category Name</label>
<input type="text" name="name" value="<?php echo $catName?>">
<br><br>
 <input type="submit" name="btnupdate" value="Update Category">
</form>
</body>
</html>
<?php
	if(isset($_POST['btnupdate']))
{
	echo $id ." id...";
	$id = $_POST ['catID'];
	$name = $_POST['catName'];
	if($name){
		$sql ="UPDATE catagories SET catName=? WHERE catID=?";
		$stmt = $db1-> prepare($sql);
		$stmt -> execute([$name, $id]);
	echo "Category updating";
} else {
	$sql = "UPDATE category SET catName=? WHERE catID=?";
	$stmt = $db1-> prepare($sql);
	$stmt -> execute([$name, $id]);
	echo "Not Photo updating";}
	header("location: cat-view.php");
}
?>
