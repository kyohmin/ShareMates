
<?php
session_start();
include 'dbconnection.php';
include 'userHeader.php';
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<style>
 .background {
  width: 100%;
  height: 500px;
 
  background-size: 100% 100%;
  border: 1px solid blue;
}
h3.a{
font-family: Comic Sans MS, Comic Sans, cursive;

text-align:center;
  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
}
</style>
<div
  class="background text-center shadow-1-strong rounded mb-5 text-white"
  style="background-image: url('Img/s.jpg');"
  
>
  <h1 class="mb-3 h3">

 
 
<br><br><br><br><br><br>
 <h3 class="a">True Quanlity, Better Products for Every Customers</h3>
 
</div><br>
<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4">
      <h3>Our Story</h3>
      <p>Our Grocery shop has become one of the most popular shop in Yangon. I have done a lot of success for our shop.</p>
    </div>
    <div class="col-sm-4">
      <h3>Our Vision</h3>
      <p>Customers are the most important for the shop and we always values all the customers</p>
    </div>
    <div class="col-sm-4">
      <h3>Our Mission</h3>
      <p>To keep the service better and make more customers trust our products.</p>
    </div>
  </div>
  </div>
  <?php
// at bottom:
require('footer.php');
?>