<?php
    session_start();
    $id=$_GET['productID'];
    $_SESSION['cart'][$id]++;
    header("Location:UsersProduct.php");
    ?>