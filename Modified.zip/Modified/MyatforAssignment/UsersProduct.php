<?php
session_start();
include 'dbconnection.php';
include 'userheader.php';

$Categories= "SELECT * FROM catagories";
$resltcat= $db1->query($Categories);
?>


<html>
<head>
<style type="text/css">
    .cart{
    margin:10px; padding:10px;
    }
   
</style>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdeliver.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body></body>
<div class="container mx-auto">
<div class="row cat">
<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 border">
<ul class="list-group">
<li style="List-style: none;" class="list-group-item active">
<b><a href="UsersProduct.php" style="text-decoration:none;">All Categories</a></b>
</li>
<?php foreach($resltcat as $row) {?>

<li style="list-style:none;" class="list-group-item">
<a href="UsersProduct.php?cat=<?php echo $row['catID']?>" style="text-decoration:none;">
<?php echo $row['catName']?></a>
</li>
<?php } ?>
</ul>
</div>
<?php 
if(isset($_POST['SearchProduct'])){
    $search=$_POST['SearchProduct'];
    $sql = "SELECT * FROM products WHERE productName like '%$search%'";
    $resproductall = $db1->query($sql);
    $count= $resproductall->rowCount();
    
}
else if(isset($_GET['cat'])){
    $cat_id = $_GET['cat'];
    $result ="SELECT * FROM products WHERE catID = $cat_id";
    $resproductall= $db1->query($result);
}else{
    $result = "SELECT * FROM products";
    $resproductall= $db1->query($result);
}
?>
<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 border">
<div class="row border">
<?php foreach($resproductall as $row) {?>
<div class="col-4 border">
<img class="img-responsive img-thumbnail bg-image" src="Img/<?php echo $row['productPhoto']?>" alt="">
<p><?php echo $row ['productName']?></p>
<p style="text-align:center"><?php echo "Price : ".$row['price']?></p>
<div class="row border mx-auto">
<button type="button" class="btn btn-primary">
<a href="add-to-cart.php?productID=<?php echo $row['productID']?>"style="text-decoration:none;color:white;">
Add to Cart</a>

</button>
</div>
</div>

<?php } ?>
</div>
</div>
</div>
</div>


</html>
 <?php

require('footer.php');
?>