<?php
include("dbconnection.php");
$id= $_GET['id'];
$sql ="DELETE FROM catagories WHERE catID= $id";
$db1 ->exec($sql);

header("location: cat-view.php");
?>
