<?php
session_start();
$id = $_POST['code']; //accept ptoduct id
$Quantity = $_POST['quantity'];
$_SESSION['cart'][$id] = $Quantity;
header("location:viewcart.php");
?>