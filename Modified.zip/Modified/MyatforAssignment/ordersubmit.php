<?php
session_start();
include ("dbconnection.php");
include 'userheader.php';

if(isset($_SESSION['id']))
{
    $phone = $_POST['phone'];
    $address=$_POST ['address'];
    $u=$_SESSION['id'];
    echo "User ID".$u;
    $db1->query("INSERT INTO tblorder (uid,order_date, phone,address) VALUES('$u', now(), '$phone','$address')");
    $order_id=$db1->lastInsertID();
    
    foreach($_SESSION['cart'] as $id=>$qty){
        $db1->query("INSERT INTO orderitem (productID, order_id, qty) VALUES ($id,$order_id,  $qty)
");
    }
    
    session_destroy();
    echo "Your order has been submitted";
    
    ?>
  <?php 
}
else if (!isset($_SESSION['id'])){
    ?>
<?php } ?>
<html>
<head>

<title>Products Order Submitted</title>
<link rel="stylesheet" href="css/style.css">
<meta http-equiv="refresh" content="1">
</head>
<body>
  <h1>Product Order Submitted</h1>
  <div class="msg">
  Your order has been submitted. We'll deliver the items soon.
  <a href="UsersProduct.php" class="done"> Product Store Home</a>
  </div>
  <div class="footer">
  &copy; <?php echo date("Y")?>.All right reserved.
  </div>
</body>
</html>