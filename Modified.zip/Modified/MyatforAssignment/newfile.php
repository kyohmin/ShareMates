<?php
session_start();
include 'dbConnection.php';
include 'adminHeader.php';

$Categories= "SELECT * FROM category";
$resultcat= $db1->query($Categories);
?>
<html>
<head>
	<style type="text/css" >
	
	    img:hover{
		      transform: scale(1.08);
		      }
		  img:hover::before{
		      left:10px;
		      top:10px;
		      } 
		  img:hover::before{
		     right:10px;
		      bottom:10px;
		      }
	   .cat{
	        margin:10px; padding:10px;
	        }
	</style>
    	<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
    	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>


</head>

<body>
	<div class="container mx-auto">
		<div class="row cat">
			<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 border">
				<ul class="list-group">
					<li style="List-styple: none;" class="list-group-item list-group-item-primary">
						<b><a href="SearchByCategory.php" style="text-decoration:none;">All Categories</a></b>
					</li>
					<?php 
					   foreach($resultcat as $row) {?>
	 						<li style="List-style: none;" class="list-group-item list-group-item-info">
	 							<a href="SearchByCategory.php?cat=<?php echo $row['CategoryID']?>" style="text-decoration:none;">
	 								<?php  echo $row['CategoryName']?>
	 							</a>
	 						</li>	
					  
				<?php }?>
				</ul>
			</div>
			<?php
			if(isset($_POST['SearchProduct'])){
			    $search=$_POST['SearchProduct'];
			    $sql = "SELECT * FROM product WHERE ProductName like '%$search%'";
		        $resproductall = $db1->query($sql);
			    $count= $resproductall->rowCount();
			    
			}
			  else if(isset($_GET['cat']))
			     {
			         $cat_id= $_GET['cat'];
			         $result= "SELECT * FROM product WHERE CategoryID=$cat_id";
			         $resproductall= $db1->query($result);
			     }
			     else {
			         $result= "SELECT *FROM product";
			         $resproductall=$db1->query($result);
			     }
			?>
				<div class="col-lg-9 col-md-9 col-sm-12 mx-auto border">
					<div class="row border">
						<?php foreach($resproductall as $row) {?>
						<div class="col-4 border">
							<img class="img-responsive img-thumbnail bg-image" src="Capital/<?php echo $row['Image']?>" alt="">
								<p style="text-align:center";><?php  echo $row['ProductName']?></p>
								<p style="text-align:center";><?php echo $row['Price'] ?></p>
							<div class="row border mx-auto">
								<button type="button" class="btn btn-info">
									<a href="add-to-cart.php?id=<?php echo $row['id']?>" style="text-decoration:none;color:white;">
										Add to cart</a>
								</button>
								
							</div>
							
						</div>
						
						<?php }?>
						
					</div>
				</div>		
		</div>
		
	</div>
	
	
	</body>
	</html>
	<?php
// at bottom:
require('footer.php');
?>