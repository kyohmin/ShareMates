<?php
session_start();
include 'dbconnection.php';
include 'userheader.php';
$pname=$Price="";

if(isset($_POST['btninsert']))
{
    $uname=$_POST['uname'];
    $pass=$_POST['upass'];
    $email=$_POST['email'];
    $sql="insert into users(username,password,email,role)value('$uname','$pass','$email','user')";
    $db1->exec($sql);
    echo "<div> data is inserted successfully</div>";
    
}
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<style>
from label{
    display: block;
    margin-top: 8px;
    }
</style>
</head>
<body>
	<form action="user-add.php" method="post" enctype="multipart/form-data">
	<div class="container">
	<h1>Insert User Information</h1>
	<p>Please fill in this form to add users.</p>
	<hr>
	<table>
	<tr>
	<td> <label for="pname"><b>User Name: </b></label></td>
	<td> <input type="text" class="form-control" placeholder="Enter User name" name="uname" id="uname" required> <br></td>
	</tr>
	<tr>
	<td> <label for="pname"><b>Email: </b></label></td>
	<td> <input type="text" class="form-control" placeholder="Enter Email" name="email" id="uname" required> <br></td>
	</tr>
	<tr>
	<td> <label for="pass"><b>Password: </b></label></td>
	<td> <input type="text" class="form-control" placeholder="Enter Password" name="upass" id="upass" required> <br></td>
	</tr>
	<tr>
	<td> <button type="submit" class="btn btn-info" name="btninsert">Insert</button></td>
	<td> <a href="Home.php" class="text-info">Back to Users Page&raquo; </a>
	</tr>
	
	
	</table>
	</div>
		</form>
</body>
</html>
<?php
// at bottom:
require('footer.php');
?>
    