
<?php
session_start();
include 'dbConnection.php';
include 'UserHeader.php';
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>

<body>

<div class="container mt-3">
  <h2>Frequently Asked Questions </h2>
  <div id="accordion">
    <div class="card">
      <div class="card-header">
        <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
       Do you provide grocery shopping and delivery in my a﻿rea?
        </a>
      </div>
      <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
        <div class="card-body">
     CAPITAL@HAGLMM.COM delivery area is continuously expanding via a network of independent Capital Grocery Store Associate Owners. To determine if WeGoShop.com delivers in your city, please visit the Grocery Delivery Areas page for further information. 
        </div>
      </div>
    </div>
   
   
    <div class="card">
      <div class="card-header">
        <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseThree">
		Can I change or cancel my order?
      </a>
      </div>
      <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
        
        Sure! You can cancel, or change your order within 24 hours of confirmation. Please contact us with your name and order number at:  CAPITAL@HAGLMM.COM.
		 After 24 hours, your order will have been processed and we won’t be able to make any changes or cancel it.
 </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseFour">
         What methods of payment do you take?
        </a>
      </div>
      <div id="collapseFour" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
         We accept ALL major credit cards, Visa, PayPal, MasterCard and Amazon Pay .

All payments are securely processed with 128-bit encryption - nice! 
        </div>
      </div>
    </div>
<!--      <div id="accordion"> -->
<!--     <div class="card"> -->
<!--       <div class="card-header"> -->
<!--         <a class="btn" data-bs-toggle="collapse" href="#collapseFive"> -->
<!--        Can I trust capital grocery store to pick my meat, produce and other fresh foods? -->
<!--         </a> -->
<!--       </div> -->
<!--       <div id="collapseFive" class="collapse show" data-bs-parent="#accordion"> -->
<!--         <div class="card-body"> -->
<!--       Absolutely! Our shoppers will shop for your meats, produce and other fresh foods just as if they were shopping for themselves, including checking for the latest expiration date. If we don't feel that it's good enough for us, why would it be good enough for you? We pride ourselves on customer satisfaction and we believe that if you are not a satisfied client then you wont be a repeat client.  -->
<!--         </div> -->
<!--       </div> -->
<!--     </div> -->
    
    
  </div>
</div>
  </div>  
</body>
</html>


  <?php
// at bottom:
require('footer.php');
?>