 <?php
session_start();
include 'dbConnection.php';
?>

<!DOCTYPE html>
<html>

<head>
<meta charset="UFT-8">
<title>
	

</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/cs
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
           <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</head>

<style type="text/css" >
    h4.a{
    font-family: Comic Sans MS, Comic Sans, cursive;
 color: white;
  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
    }
    .center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 20%;
}
</style>
<body>
   <section class="vh-500" style="background-color: lightblue;">
  <div class="container py-5 h-100" style="background-color: lightblue;">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-30">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
          
             
            </div>
            
              <div class="card-body p-4 p-lg-5 text-black">
    
    
    	<div class="container">
    	<div id="login-row" class="row justify-content-center">
    	<div id="login-column" class="col-md-6">
    	<div id="login-box" class="col-md-12">
    	
    	<h4 class="a">Capital Grocery Store Admin Login Form</h4>
    	  <form method="post">
    	<div class="form-group">
    	<label for="username" class="text-info">Email: </label>
    	<input type="email" name="email" id="email" class="form-control">
    	</div>
    	
    	<div class="form-group">
    	<label for="password" class="text-info">Password: </label>
    	<input type="password" name="password" id="password" class="form-control">
    	</div>
    	
    	<div class="form-group">
    	<label for="remember-me" class="text-info">Remember me</span>
    	<span><input id="remember-me" name="remember-me"  type="checkbox"></span></label><br>
    	
    	
    	  <button type="submit" name="login">Login</button>
    </form> 
    	</div>
    	
    	
              <div id="register-link" class="text-right"><a href="admin-add.php">Register here</a> </td>
        <br><!--  -->
     
		</div>
	    

     </div>
   </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>
<?php 
try {
    if (isset($_POST["login"])){
        
        $message='<span class="label label-info">All fields are required.</span>';
        
        $email=$_POST["email"];
        $password=$_POST["password"];
        
        
        $query="SELECT * FROM admin WHERE Email='$email' AND Password='$password' AND Role='admin'";
        $statement1=$db1->query($query);
        
        $admins=$statement1->fetchAll(PDO::FETCH_ASSOC);
        $countAdmin=$statement1->rowCount();
        
        echo $countAdmin;
        if ($countAdmin>0){
            foreach ($admins as $rows){
                $_SESSION["id"]=$rows["id"];
                $_SESSION["username"]=$rows["AdminName"];
                
                
                header("location:adminhome.php");
            }
        }
        
        
    }
    
}
catch (PDOException $error){
    $message=$error->getMessafe();
}
?>