<html>
<body>
	<h1 style="background: Brown;color:white;text-align:center;">Search Information</h1>
	<form action="" method="post" style="color:black;text-align:center;margin:0 auto;width:400;">
	<table width="400" align="center">
		<tr>
			<td width=100>
				<b>Search</b>
			</td>
			<td width=300>
				<input type="text" name="search" value="" style="width:300;border-color:gray;"><br>
			</td>
		</tr>
		<tr>
			<td>
			<input type="submit">
			</td>
			<td>
			<input type= "submit" value ="Show all record">
			</td>
		</tr>
	</table>
	</form>
</body>
</html>

<?php
include 'dbconnection.php';
include 'adminheader.php';

    if(isset($_POST['search']))
     {
         $search=$_POST['search'];
         echo "Search name: ".$search."<br>";
        $sql = "SELECT * FROM products WHERE productName like '%$search%'";
        echo "SQL:" .$sql. "<br>";
        $result = $db1->query($sql);
    }
?>
<html>
<body>
	<table border="1" class="table table-success table-striped" align="center">
		<tr>
			<th colspan="5"> Product List</th>
		</tr>
		<tr>
			<th>Product ID</th>
			<th>Product Name</th>
			<th>Price</th>
			<th>Edit</th>
			<th>Delete</th>
		</tr>
		
		
<?php 
if(isset($result)){
    if($result->rowCount()> 0){
 
    foreach($result as $row){?>
    	<tr>
    		<td><?php echo $row['productID']?></td>
    		<td><?php echo $row['productName']?></td>
    		<td><?php echo $row['price']?></td>
    		<td> [<a href="cat-del.php?id=<?php echo $row['productID']?>">del</a>]</td>
    		<td>[<a href="cat-edit.php?id=<?php echo $row['productID']?>">edit</a>]</td>
    	</tr>

<?php }
  }
else{
    echo "0 records";
}}
?>
	</table>
	<h1 style="background: brown;color:white;text-align:center;">Created by Capital</h1>
</body>
</html>



















