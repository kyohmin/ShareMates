<?php
include 'dbconnection.php';
include 'adminheader.php';
$pname="";

if(isset($_POST['btninsert']))
{
    $pname=$_POST['pname'];
    $sql="insert into product(productName)values('$pname')";
    $db1->exec($sql);
    echo"<div> New Product is inserted successfully</div>";
}
?>
 <html>
 <head>
 <title>New Product</title>
 <style>
 form label{
 display: block;
 margin-top: 8px;
 }
 </style>
 </head>
 <body>
 <form method="POST" action="product-add.php" enctype="multipart/form-data">
 <table>
 <tr>
 	<td><label for="pname"><b>Product Name:</b></label></td>
 <td><input type="text" class= "form-control" placeholder="Enter Product name" name="pname" id="pname" required><br></td>
 </tr>
 <tr>
 	<td>Category ID:</td>
 <td><input type="text" name="catid" placeholder="id" required></td>
 </tr>
 <tr>
 <td>Price:</td>
 <td><input type="text" name="price" placeholder="0" required></td>
 	</tr>
 	<tr>
 	<td>
 	<label>Photo:</label>
 </td>
 <td>
 <input type="file" name="productPhoto" id="productPhoto">
 </td>
 </tr>
 </table>
 <input type="submit" name="Submit">
 <a href="product-view.php">Go to Product List</a>
 </form>
 <?php 
 //if($_SERVER["REQUEST_METHOD"] == "POST"){
 if(isset($_POST['Submit'])){
     $productName = $_POST['pname'];
     $catID = $_POST['catid'];
     $price = $_POST['price'];
     $productPhoto = $_FILES['productPhoto']['name'];
     $tmp = $_FILES['productPhoto']['tmp_name'];
     echo $productPhoto;
     if($productPhoto){
         move_uploaded_file($tmp, "Img/$productPhoto");
     }
     $message = $productName .'\n'.$catID.'\n'.$productPhoto;
     echo $productName .'&nbsp'.$catID.'&nbsp'.$price;
     echo"<script type='text/javascript'>alert('".$message."');</script>";
     
     //Create Our SQL query
     $sql="INSERT INTO products(productName,catID,price,productPhoto) VALUES(?,?,?,?)";
     $stmt= $db1->prepare($sql);
     $stmt->execute([$productName, $catID,$price,$productPhoto]);
     echo"<script type='text/javascript'>alert('saving successfully');</script>";
 }
?>
 </body>
 </html>