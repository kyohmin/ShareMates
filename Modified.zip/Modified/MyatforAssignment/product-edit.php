<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>Edit Products</title>
</head>
<body style="background-color: #CCCCFF;">
<h1>Edit Products</h1>
<?php 
    include("dbconnection.php");
    $id=$_GET['catID'];
    $result=$db1->query("SELECT * FROM products WHERE productID=$id");
    if($result->rowCount() >0){
        foreach($result  as $row){
            $id=$row['productID'];
            $productName=$row['productName'];
            $catID=$row['catID'];
            $price=$row ['price'];
          
            $photo=$row['productPhoto'];
        }
    }
?>
<form method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?php echo $productID ?>">

<label for="name">Product Name</label>
<input type="text" name="name" value="<?php echo $productName?>">
<br><br>
<label for="remark" >CategoryID</label>
<input type="text" name="catID" value="<?php echo $catID ?>">
<br><br>
<label for="price" >Price</label>

<input type="text" name="price" value="<?php echo $price ?>">
<br>
<img src="img/<?php echo $photo ?>" alt=""height="150">
 <label for="img">Change Photo</label>
 <input type="file" name="img" id="img">
 <br><br>
 <input type="submit" name="btnupdate" value="Update Product">
</form>
</body>
</html>
<?php
	if(isset($_POST['btnupdate']) )
{
	echo $id ." id...";
	$id = $_POST ['id'];
	$productName = $_POST['name'];
	$catID= $_POST['catID'];
	$price = $_POST['price'];
	$photo= $_FILES['img'] ['name'];
	$tmp = $_FILES ['img'] ['tmp_name'];

	if ($photo) {
		move_uploaded_file($tmp,"img/$photo");
		$sql ="UPDATE products SET productName=?, catID=?, price=? ,productPhoto=? WHERE productID=?";
		$stmt = $db1-> prepare($sql);
		$stmt -> execute([$productName, $catID, $price ,$photo, $id]);
	echo "Photo updating";
} else {
    $sql ="UPDATE products SET productName=?, catID=?, price=? WHERE productID=?";
    $stmt = $db1-> prepare($sql);
    $stmt -> execute([$productName, $catID, $price, $id]);
	echo "Not Photo updating";}
	header("location: product-view.php");
}
?>
