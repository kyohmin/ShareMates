
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
                            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> 
</head>
<!-- Navbar -->

  <!-- Navbar content -->

<nav class="navbar navbar-expand-lg navbar-light bg-secondary">

<div class="container-fluid" >


    <a class="navbar-brand" style="color:black" href="#"  >
      
      Captial
    </a>
<button
class="navbar-toggler"
    type="button"
        data-mdb-toggle="collapse"
            data-mdb-target="#navbarExample01"
                aria-controls="navbarExample01"
                    aria-expanded="false"
                        aria-label="Toggle navigation"
                            >
                           
 				<i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
        <li class="nav-item">
          <a class="nav-link" style="color:white" aria-current="page" href="adminhome.php">Home</a>
                            </li>
                            <li class="nav-item">
                           <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" style="color:white" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
       Product Management
          </a>
          <ul class="dropdown-menu dropdown-menu-white" aria-labelledby="navbarDarkDropdownMenuLink">
          <li><a class="dropdown-item" href="product-add.php">Add Product</a></li>
                       <li><a class="dropdown-item" href="SearchProduct.php">Search By Product</a></li>
            <li><a class="dropdown-item" href="product-view.php">View All Products</a></li>
           
          </ul>
        </li>
        <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" style="color:white" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
       Category Management
          </a>
          <ul class="dropdown-menu dropdown-menu-white" aria-labelledby="navbarDarkDropdownMenuLink">
          <li><a class="dropdown-item" href="cat-add.php">Add Category</a></li>
                       <li><a class="dropdown-item" href="SearchByCategory.php">Search By Category</a></li>
            <li><a class="dropdown-item" href="cat-view.php">View All Categories</a></li>
           
          </ul>
        </li>
         <li class="nav-item">
          <a class="nav-link" style="color:white" aria-current="page" href="ViewAllUsers.php">View User Info</a>
                            </li>
         
            </div>
                           </li>
                           </ul>
                         
<!--           <div id="form"> -->
<!--                	<form method="post" action="SearchByCategory.php" enctype="multipart/form-data"> -->
               		
               		
<!--                <input type="text" name="SearchProduct" placeholder="Search"> -->
<!--                	<input type="submit" name="Search" value="Search"> -->
<!--                	</form> -->
<!--                	</div> -->
<!--                </div>    -->
<!--           </form> -->
  </ul>
      
      <?php 
      $cart = 0;
      if(isset($_SESSION['cart'] ))
      {
          foreach($_SESSION['cart']as $qty){
              $cart += $qty;
          }
      }
      ?>
      <?php if(isset($_SESSION["username"]))
      {
          $username = $_SESSION["username"];
      }
      ?>
        
      
     
     
      		<a href="view-cart.php" class="cart position-relative d-inline-flex mt-3" style="text-decoration:none;">
<img src="https://img.icons8.com/external-kiranshastry-solid-kiranshastry/64/000000/external-shopping-cart-ecommerce-kiranshastry-solid-kiranshastry.png"/>      			<?php  echo $cart ?>
      		</span>
      </a>
     
		
			<a class="nav-link" href="login1.php">
	 <img src="https://img.icons8.com/external-flatart-icons-lineal-color-flatarticons/64/000000/external-login-web-security-flatart-icons-lineal-color-flatarticons.png"/>
 		
</a>
		
		
			<a class="nav-link dropdown-toggle mt-2" href="" data-bs-toggle="dropdown">
			<?php 
			 if(isset($_SESSION["username"]))
			 {
			     echo $_SESSION["username"];
			 }
			 else {?>
			 	<img src="https://img.icons8.com/external-sbts2018-blue-sbts2018/58/000000/external-logout-social-media-basic-1-sbts2018-blue-sbts2018.png"/> 
			  <?php } 
			  ?></a>   
			  <ul class="submenu dropdown-menu">
			  	<li> <a class="dropdown-item" href="login.php">logout</a></li>
		</ul>
		</li>	
      </ul>
    </div>
    </div>
    </nav>
                            </header>
                            
                            <title>Products</title>
   <style>
  ul li a.cart .cart-basket{
  font-size: .6rem;
  position: absolute;
  top: -6px;
  right:-5px;
  width: 15px;
  height: 15px;
  color: #fff;
  background-color: #418deb;
  border-radius: 50%;
  }
  
  ul li a.cart:hover{
   text-decoration: none;
   color: #d60e96;
   }
   
   ul li a{
   font-size: 1.1rem;
   color:#343140;
   }
   
   .fas {
   font-size: 50px;
   font-style: italic;
  
  
   }
   
   .naver {
   color:blue;
   }
   .login{
   padding-left: 2.1vw;
    padding-right: 4.1vw;
   }
   .logout{
    
     padding-left: 1.1vw;
    padding-right: 2.1vw;
   
   }
   a.navbar-brand{
    font-family: Comic Sans MS, Comic Sans, cursive;
     text-shadow: 2px 2px 4px #000000;
   }
     li.nav-link dropdown-toggle{
    
     
     }
   </style>                         
 
                     
           
 </html>
</head>
<?php 
$cart=0;
if (isset($_SESSION['cart'])){
    foreach ($_SESSION['cart'] as $qty){
        $cart+=$qty;
    }
}
?>
 
  
    	