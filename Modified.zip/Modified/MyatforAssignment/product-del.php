<?php
include("dbconnection.php");
$id= $_GET['id'];
$sql ="DELETE FROM products WHERE productID = $id";
$db1 ->exec($sql);

header("location: product-view.php");
?>
