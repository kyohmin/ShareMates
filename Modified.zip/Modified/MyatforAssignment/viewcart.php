<?php
session_start();
include 'dbconnection.php';
include 'userheader.php';


if(!isset($_SESSION['cart']))
{
    header("UsersProduct.php");
    exit();
}
?>

<html>
<head>
	<title>View Cart</title>
	<link rel="sylesheet" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
	
  </script>

</head>
<body>
	<h1> View Cart</h1>
	<div class="sidebar">
	<ul class="cats">
	<li><a href="UsersProduct.php">&laquo; Continue Shopping</a></li>
	<li><a href="clearcart.php" class="del">&times; Clear Cart</a></li>
	</ul>
	</div>
	<div class="main">
	<table border="1">
		<tr>
			<th>Product Name</th>
			<th>Quantity</th>
			<th>Unit Price</th>
			<th>Price</th>
		</tr>
		<form method="POST" action="viewcart.php">
		<?php 
		  $total = 0;
		  $p = 0;
		  foreach($_SESSION['cart'] as $productID=>$Quantity):
		      
		      $result=("SELECT productName, price FROM products WHERE productID=$productID");
		          foreach($db1->query($result)as $row)
		          {
		              $p=$row['price'];
  
		          }
		  $total += $row['price'] * $Quantity; 
		?>
			<tr>
				<td><?php  echo $row['productName']?></td>
				<td>
				<input onclick="save(this);" size="2" type="number" name="qty" step="1" id="<?php echo $productID ?>" value="<?php echo $Quantity?>">
				</td>
				
				<td><?php  echo $row['price']?></td>
				<td id="total"><?php  echo $row['price'] * $Quantity?></td>
				<td>
				<button type="submit" class="btn btn-warning">
				Update
				</button>
				</td>
			<script>
    function save(obj){
    var quantity=$(obj).val();
    var code=$(obj).attr("id");
    $.ajax({
    url:"Updatecart.php",
    type:"POST",
    data:'code='+code+'&quantity='+quantity,
    //success:function(data){}
    });
			
				 }	
			</script>
				<td>
				
					<td><button type="submit" class="btn btn-warning"><a href="delcart.php? productID=<?php echo $productID?>" style="text-decoration:none;">delete</a></button>
</td>
				</td>	
			</tr>
			<?php 
			     endforeach; 
			?>
			<tr>
				<td colspan="3" align="right" style="font-weight:bold; font-size:20px;"><b>Total:</b></td>
				<td colspan="2" class="total" style="font-weight:bold; font-size:20px;"><?php echo $total; ?></td>
			</tr>
			<tr>

<td colspan="3" align="center">
	<button type="button" class="btn btn-info"><a href="UsersProduct.php"> Continue Shopping</a></button>
</td>
<td colspan="2" align="right">
	<button type="button" class="btn btn-info"><a href="clearcart.php">&times; Clear Cart</a></button>
</td>
</tr>

</table>
</form>

</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
<div class="row border order">
<h2 class="display-6">OrderNow</h2>
<form action="ordersubmit.php" method="post">
<div class="col-md-6"></div>

</div>
<div class="col-md-12">
<label for="name">Your name</label>
<input type="text" name="name" class="form-control" id="name" disabled value=<?php if(!isset($_SESSION['username'])){
    echo "";
}
else{
    echo $_SESSION['username'];}?>>
</div>
<div class="col-md-12">
<label for="email">Email</label>
<input type="text" name="email" class="form-control" id="email" disabled value=<?php if(!isset($_SESSION['email'])){
    echo "";
}
else{
    echo $_SESSION['email'];}?>>
</div>

<div class="col-md-12">
<label for="phone">Phone</label>
<input type="text" name="phone" id="phone" class="form-control">
</div>

<div class="col-md-12">
<label for="address">Address</label>
<textarea name="address" id="address" class="form-control"> </textarea>
</div>

<div class="col-md-12">
<tr>
			<td>Shipping</td>
			<td class="d-flex justify-content-center">
			<ul class="shipping-type">
			<li>
				<div class="custom-control custom-radio">
					<input type="radio" id="flatrate" name="shipping"
						class="custon-control-input" checked/>
					<label class="custom-control-label" for="flatrate">Flat Rate:
						$70.00</label>
				
				</div>
				</li>
			<li>
				<div class="custom-control custos-radio">
					<input type="radio" id="freeshipping" name="shipping"
						class="custom-control-input"/>
					<label class="custom-control-label" for="freeshipping">Free
						Shipping</label>
				
				</div>
				</li>
			</ul>
			</td>
			</tr>
			
		
		<div class="order-payment-method">
			<div class="single-payment-method show">
				<div class="payment-method-name">
					<div class="custom-control custom-radio">
						<input type="radio" id="cashon" name="paymentmethod" value="cash"
							class="custom-control-input" checked/>
						<label class="custom-control=label" for="cashon">Cash on Delivery</label>
					</div>
					
					</div>
					<div class="payment-method-details" data-method="check">
		           <p>Please send a check to Store Name, Store Street, Store Town, Store State / 
		              County, Store Postcode.</p>
		        </div>
		   </div>

		   <div class="single-payment-method">
		    <div class="payment-method-name">
			<div class="custom-control custom-radio">
			     <input type="radio" id="paypalpayment" name="paymentmethod" value="paypal"
				class="custom-control-input"/>
			     <label class="custom-control-label" for="paypalpayment">Paypal 
			     <img src="https://img.icons8.com/color/48/000000/paypal.png"/></label>
			 </div>
		    </div>
		    <div class="payment-method-details" data-metod="paypal">
		        <p>Paypal VISA Mastercard; you can pay with your credit card if you don't have a PayPal 
		           account.</p>
		    </div>
		</div>
		
		<div class="single-payment-method">
		    <div class="payment-method-name">
			<div class="custom-control custom-radio">
			     <input type="radio" id="paypalpayment" name="paymentmethod" value="paypal"
				class="custom-control-input"/>
			     <label class="custom-control-label" for="paypalpayment">VISA card
			     <img src="https://img.icons8.com/color/48/000000/visa.png"/></label>
			 </div>
		    </div>
		    <div class="payment-method-details" data-metod="paypal">
		        <p>Paypal VISA Mastercard; you can pay with your credit card if you don't have a VISA 
		           account.</p>
		    </div>
		</div>
		
		<div class="single-payment-method">
		    <div class="payment-method-name">
			<div class="custom-control custom-radio">
			     <input type="radio" id="paypalpayment" name="paymentmethod" value="paypal"
				class="custom-control-input"/>
			     <label class="custom-control-label" for="paypalpayment">Mastercard 
			     <img src="https://img.icons8.com/fluency/48/000000/mastercard.png"/></label>
			 </div>
		    </div>
		    <div class="payment-method-details" data-metod="paypal">
		        <p>Paypal VISA Mastercard; you can pay with your credit card if you don't have a Mastercard 
		           account.</p>
		    </div>
		</div>

</div>

<div class="col-md-12">

<?php if(!isset($_SESSION['id'])){?>   
<input type="submit"  value="Submit Order" >
<?php }?>
<?php if(isset($_SESSION['id'])){?>
<input type="submit"  value="Submit Order">
<?php }?>
<a href="UsersProduct.php">Continue Shopping</a>
</div>

</div>
</form>
</div>
</div>
</div>


</body>

</html>
 <?php

require('footer.php');
?>
				
