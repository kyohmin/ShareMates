<?php
include 'dbconnection.php';
include 'adminheader.php';
$cname="";

if(isset($_POST['btninsert']))
{
    $cname=$_POST['cname'];
    $sql="insert into catagories(catName)values('$cname')";
    $db1->exec($sql);
    echo"<div> New Category is inserted successfully</div>";
}
?>
 <html>
 <head>
 <title>New Category</title>
 <style>
 form label{
 display: block;
 margin-top: 8px;
 }
 </style>
 </head>
 <body>
 <form method="POST" action="cat-add.php" enctype="multipart/form-data">
 <table>
 <tr>
 	<td><label for="cname"><b>Category Name:</b></label></td>
 <td><input type="text" class= "form-control" placeholder="Enter Category name" name="cname" id="cname" required><br></td>
 </tr>
 </table>
 <input type="submit" name="Submit">
 <a href="cat-view.php">Go to Category List</a>
 </form>
 <?php 

 if(isset($_POST['Submit'])){
     $catName = $_POST['cname'];
     
     $message = $catName;
     echo $catName;
     echo"<script type='text/javascript'>alert('".$message."');</script>";
     
     //Create Our SQL query
     $sql="INSERT INTO catagories(catName) VALUE(?)";
     $stmt= $db1->prepare($sql);
     $stmt->execute([$catName]);
     echo"<script type='text/javascript'>alert('saving successfully');</script>";
 }
?>
 </body>
 </html>