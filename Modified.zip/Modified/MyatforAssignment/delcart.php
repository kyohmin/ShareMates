<?php session_start();
$id = $_GET['productID']; //accept product id
unset($_SESSION['cart'][$id]);
header("location:viewcart.php");