<?php

$servername="localhost";
$username="root";
$password="";
$db="myat1";

try{
    $db1=new PDO("mysql:host=$servername;dbname=$db",$username,$password);
    
}catch(PDOException $e)
{
    echo "connnection uncessessful".$e->getMessage();
}





?>