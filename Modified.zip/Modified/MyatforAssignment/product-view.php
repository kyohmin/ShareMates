<html>
<head>
</head>
<table border="1" class="table table-success table-striped">
<tr>
<td>ProductID</td>
<td>Product Name</td>
<td>Category ID</td>
<td>Price</td>
<td>Photo</td>
</tr>
<?php 
include'dbconnection.php';
include 'adminheader.php';
$sql='SELECT*from products';
$statement= $db1->query($sql);

$products = $statement->fetchAll(PDO::FETCH_ASSOC);
if($products){
    foreach ($products as $row){?>
    <tr>
    <td><?php echo $row['productID'];?></td>
    <td><?php echo $row['productName'];?></td>
    <td><?php echo $row['catID'];?></td>  
    <td><?php echo $row['price'];?></td>
   
    <td><img src="img/<?php echo $row['productPhoto'];?>"width="100" height="100"></td>
    <td>[<a href="product-del.php?id=<?php echo $row['productID']?>"
    		class="del" onClick="return confirm ('Are you sure?')">del</a>]</td>
    <td>[<a href="product-edit.php?id=<?php echo $row['productID']?>">edit</a>
}</td></tr>
<?php }}
?>
</table>
</html>

