<?php
session_start();
include 'dbconnection.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>User Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div>
</div>
<div class="m-4">
    <form method="post">
    	<div class="form-group">
    	<label for="username" class="text-info">Email: </label>
    	<input type="email" name="email" id="email" class="form-control">
    	</div>
    	
    	<div class="form-group">
    	<label for="password" class="text-info">Password: </label>
    	<input type="password" name="password" id="password" class="form-control">
    	</div>
    	
    	<div class="form-group">
    	<label for="remember-me" class="text-info">Remember me</span>
    	<span><input id="remember-me" name="remember-me"  type="checkbox"></span></label><br>
    	  <button type="submit" name="login">Login</button>
    </form> 
    	</div>
    	
    	
              <div id="register-link" class="text-right"><a href="user-add.php">Register here</a> </td>
        <br><!--  -->
     
		</div>
</div>
</body>
</html>
<?php 
try {
    if (isset($_POST["login"])){
        
        $message='<span class="label label-info">All fields are required.</span>';
        
        $email=$_POST["email"];
        $password=$_POST["password"];
        
        $query="SELECT * FROM users WHERE email='$email' AND password='$password' AND role='user'";
        $statement1=$db1->query($query);
        
        $users=$statement1->fetchAll(PDO::FETCH_ASSOC);
        $countAdmin=$statement1->rowCount();
        
        echo $countAdmin;
        if ($countAdmin>0){
            foreach ($users as $rows){
                $_SESSION["id"]=$rows["id"];
                $_SESSION["username"]=$rows["username"];
                $_SESSION["email"]=$rows["email"];
                
                header("location:Home.php");
            }
        }
        
        
    }
    
}
catch (PDOException $error){
    $message=$error->getMessafe();
}
?>