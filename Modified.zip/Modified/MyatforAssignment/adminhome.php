<?php
session_start();
include 'dbconnection.php';
include 'adminheader.php';
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>

<style type="text/css" >
	   img
	    img:hover{
		      transform: scale(1.08);
		      }
		  img:hover::before{
		      left:20px;
		      top:10px;
		      } 
		  img:hover::before{
		     right:20px;
		      bottom:10px;
		      }
	   .h1{
	        margin:10px; padding:10px;
	      
	        }
	     .background {
  width: 75%;
  height: 500px;
 
  background-size: 100% 100%;
  border: 1px solid blue;
}
p.a{
  
  
font-family: Comic Sans MS, Comic Sans, cursive;
 color: white;
  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
  
}
a.btn {
font-family: Comic Sans MS, Comic Sans, cursive;
 color: white;
  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
}
h3.b{
font-family: Comic Sans MS, Comic Sans, cursive;

  text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
}

	</style>
<!-- Background image -->
	


<!-- Jumbotron -->
<div
  class="background text-center shadow-1-strong rounded mb-5 text-white"
  style="background-image: url('Img/cover.jpg');"
  
>
  <h1 class="mb-3 h3">

 <br><br><br>
 
 <p class="a" >Better Price Better Products for Everyone</p> <br><br><br><br>
 <a class="btn btn-primary" href="SearchByCategory.php" role="button">SHOP NOW>>></a><br><br>
 </h1>
 
</div>



<!-- Gallery -->
<div class="row">
<h3 class="b" style="background: lightblue;color:white;text-align:center;">Special Products</h3>
  <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
    <img
      src="Img/apl.jpg"
      class="w-100 shadow-1-strong rounded mb-4"
      alt="Boat on Calm Water"
    />

    <img
      src="Img/fruit.jpg"
      class="w-100 shadow-1-strong rounded mb-4"
      alt="Wintry Mountain Landscape"
    />
  </div>

  <div class="col-lg-4 mb-4 mb-lg-0">
    <img
      src="Img/chp.jpg"
      class="w-100 shadow-1-strong rounded mb-4"
      alt="Mountains in the Clouds"
    />

    <img
      src="Img/meat.jpg"
      class="w-100 shadow-1-strong rounded mb-4"
      alt="Boat on Calm Water"
    />
  </div>

  <div class="col-lg-4 mb-4 mb-lg-0">
    <img
      src="Img/des.jpg"
      class="w-100 shadow-1-strong rounded mb-4"
      alt="Waves at Sea"
    />

    <img
      src="Img/cold.jpg"
      class="w-100 shadow-1-strong rounded mb-4"
      alt="Yosemite National Park"
    />
  </div>
</div>
<!-- Gallery -->

<!-- Jumbotron -->
<!-- Background image -->

