<html>
<head>
</head>
<table border="1" class="table table-success table-striped">
<tr>
<td>Category ID</td>
<td>Category Name</td>
</tr>
<?php 
include'dbconnection.php';
include 'adminheader.php';
$sql='SELECT*from catagories';
$statement= $db1->query($sql);

$catagories = $statement->fetchAll(PDO::FETCH_ASSOC);
if($catagories){
    foreach ($catagories as $row){?>
    <tr>
    <td><?php echo $row['catID'];?></td>
    <td><?php echo $row['catName'];?></td>
    
    
    <td>[<a href="cat-del.php?id=<?php echo $row['catID']?>"
    		class="del" onClick="return confirm ('Are you sure?')">del</a>]</td>
    <td>[<a href="cat-edit.php?id=<?php echo $row['catID']?>">edit</a>
}</td></tr>
<?php }}
?>
</table>
</html>
