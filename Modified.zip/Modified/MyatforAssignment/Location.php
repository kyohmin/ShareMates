   
<?php
session_start();
include 'dbconnection.php';
include 'userheader.php';
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<style>
 .background {
  width: 50%;
  height: 500px;
 
  background-size: 100% 100%;
  border: 1px solid blue;
}
h3.a{
font-family: Comic Sans MS, Comic Sans, cursive;

text-align:center;
  text-shadow: 1px 1px 2px black, 0 0 25px black, 0 0 5px darkblue;
}
p.a{
font-family: Comic Sans MS, Comic Sans, cursive;

text-align:center;
  text-shadow: 1px 1px 2px black, 0 0 25px black, 0 0 5px darkblue;
}
</style>
<!-- Jumbotron -->

    <div
  class="background text-center shadow-1-strong rounded mb-5 text-white"
  style="background-image: url('Img/map.png');">
  


<!-- Jumbotron -->


    


</div><br>


<div class="container mt-5">
  <div class="row">
<h3>Location</h3>
<p> 192, Hlae Tan, Insein Road, Yangon</p>

  <div class="row">
<h3>Opening Hours</h3>
<p> Monday to Sunday: 9am to 9pm</p>
  <div class="row">
<h3>Email</h3>
<p>Capital@Myat.MM.COM</p>

  <div class="row">
<h3>Phone</h3>
<p>+959 001 989 780 </p>
<p>+959 001 989 781
</p>
<div class="container py-4">

  

</div>
</div>
</div>
</div>
</div>
</div>
<?php
// at bottom:
require('footer.php');
?>