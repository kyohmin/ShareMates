<html>
<head>

</head>
<table border="1" class="table table-success table-striped">
 
	<tr>
		<td>Customer ID</td>
		<td>Customer Name</td>
		<td>Email</td>
		
	</tr>
<?php 
    include 'dbConnection.php';
    include 'adminHeader.php';
    $sql = 'SELECT* from users';
    $statement = $db1->query($sql);
    
    //get all publishers
    
    $products = $statement->fetchAll(PDO::FETCH_ASSOC);
    if ($products){
        //show the publishers
        foreach ($products as $row){?>
       
        <tr>
        	<td><?php echo  $row['id'];?></td>
        	<td><?php echo  $row['username'];?></td>
        	<td><?php echo  $row['email'];?></td>
        	
        	
        	</tr>
 
	<?php }
}
	?>	
</table>

</html>
